<?php
// connect to database
$db = mysqli_connect('localhost', 'root', '', 'contactusers');

// REGISTER USER
if (isset($_POST['reg_user'])) {
	// receive all input values from the form
	
	$name = mysqli_real_escape_string($db, $_POST['name']);
	$email = mysqli_real_escape_string($db, $_POST['email']);
	$subject = mysqli_real_escape_string($db, $_POST['subject']);
	$message = mysqli_real_escape_string($db, $_POST['message']);

	// form validation: ensure that the form is correctly filled
	if (empty($name)) { array_push($errors, "Please enter Your Name"); }
	if (empty($email)) { array_push($errors, "Please enter your email"); }

	// register user if there are no errors in the form
	if (count($errors) == 0) {
		
		$query = "INSERT INTO users (name,email,subject,message) 
				  VALUES('$name', '$email', '$subject', '$message')";
		mysqli_query($db, $query);
     echo"<center>"."Your details have been successfully submitted"."</center>";
	
	}

}
?>